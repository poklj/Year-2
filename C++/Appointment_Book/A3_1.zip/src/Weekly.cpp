/*
 * Weekly.cpp
 *
 *  Created on: Nov 6, 2018
 *      Author: zach
 */

#include "Weekly.h"



Weekly::Weekly() {
	// TODO Auto-generated constructor stub

}

Weekly::~Weekly() {
	// TODO Auto-generated destructor stub
}

bool Weekly::chkOccurance(Date& Querydate){
	bool Occurs = false;
	if (0 <= period)
		Occurs = this->getDate() == Querydate;
	else
		Occurs = (0 == (this->getDate() - Querydate).getDay() % period);
	return Occurs;
}

