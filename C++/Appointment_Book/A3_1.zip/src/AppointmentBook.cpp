/*
 * AppointmentBook.cpp
 *
 *  Created on: Nov 5, 2018
 *      Author: zach
 */

#include "AppointmentBook.h"
#include "CODEOPT.h"

AppointmentBook::AppointmentBook() {
}

AppointmentBook::~AppointmentBook() {
	for(Appointment* a : this->Appointmentlist){
		if(!a)
			delete a;
	}
}


bool AppointmentBook::createAppointment(ApptType value){

	try{
		switch(value){
		default :
		case (SINGLE): {
			Appointment* a;
			if(PURE == 1)
				a = this->ABfactory->Create('o');
			else
				a = this->ABfactory->Create('s');

			this->Appointmentlist.push_back(a);
			break;
		}
		case (DAILY): {
			Appointment* a = this->ABfactory->Create('d');
			this->Appointmentlist.push_back(a);
			break;
		}
		case (WEEKLY): {
			Appointment* a = this->ABfactory->Create('w');
			this->Appointmentlist.push_back(a);
			break;
		}

		}
	} catch (int n){
		return false;
	}

	return true;
}
