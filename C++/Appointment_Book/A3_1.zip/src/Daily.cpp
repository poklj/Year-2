/*
 * Daily.cpp
 *
 *  Created on: Nov 5, 2018
 *      Author: zach
 */

#include "Daily.h"

Daily::Daily() {
	// TODO Auto-generated constructor stub

}

Daily::~Daily() {
	// TODO Auto-generated destructor stub
}

//Good lord I can just put this in the baseclass and just have a virtual integer
bool Daily::chkOccurance(Date& Querydate){
	bool Occurs = false;
	if (0 <= period)
		Occurs = this->getDate() == Querydate;
	else
		Occurs = (0 == (this->getDate() - Querydate).getDay() % period);
	return Occurs;
}


