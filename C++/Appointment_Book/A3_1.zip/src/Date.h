/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Date.h
 * Author: user
 *
 * Created on November 3, 2018, 8:33 PM
 */

#ifndef SRC_DATE_H
#define SRC_DATE_H

class Date {
public:
    Date();
    Date(int, int, int);
    Date(const Date& orig);
    virtual ~Date();

    bool operator==(Date& o){
        return day == o.getDay() && month == o.getMonth() && year == o.getYear();
    }

    Date operator-(Date& o){
    	int Day = o.getDay() - day;
    	int Month = o.getMonth() - month;
    	int Year = o.getYear() - year;

        return Date(Day, Month, Year);
    }
    Date operator+(Date& o){
    	int Day = (o.getDay() - day)*-1;
    	int Month = (o.getMonth() - month)*-1;
    	int Year = (o.getYear() - year)*-1;

    	return Date(Day, Month, Year);
    }
    bool operator<=(Date& o){
    	return day <= o.getDay() || month <= o.getMonth() || year <= o.getYear();
    }
    bool operator>=(Date& o){
    	return day >= o.getDay() || month >= o.getMonth() || year >= o.getYear();
    }
    
    void setDay(int);
    void setMonth(int);
    void setYear(int);
    
    int getDay();
    int getMonth();
    int getYear();
    

    bool isValid();
private:
    int day;
    int month;
    int year;
};

#endif /* DATE_H */

