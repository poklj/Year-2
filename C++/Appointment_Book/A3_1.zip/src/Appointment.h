/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Appointment.h
 * Author: user
 *
 * Created on November 3, 2018, 8:28 PM
 */

#ifndef APPOINTMENT_H
#define APPOINTMENT_H

#include "Date.h"
#include "Time.h"
#include <string>
#include <FactoryC++11.h>
#include "CODEOPT.h"
class Appointment {
public:
    Appointment();
    Appointment(const Appointment& orig);
    virtual ~Appointment();
    
    
    //Don't Pure virtual this as an "Appointment" is a single occurance type
    virtual bool chkOccurance(Date&) OPT_PURE;
    
    void setDate(int, int, int);
    void setDate(Date);
    
    void setTime(int, int);
    void setTime(Time);
    
    void setLocation(std::string);
    void setDescription(std::string);
    void setType(std::string);
    
    Date& getDate();
    Time& getTime();
    std::string getLocation();
    std::string getDescription();
    std::string getType();
    
private:
    std::string type = "Single";
    
    Date * date = nullptr; 
    Time * time = nullptr;
    
    std::string location;
    std::string description;
    
};

//Ask Piotr how to make this allow the Register

#endif /* APPOINTMENT_H */

