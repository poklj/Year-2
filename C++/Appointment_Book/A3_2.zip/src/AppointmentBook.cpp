/*
 * AppointmentBook.cpp
 *
 *  Created on: Nov 5, 2018
 *      Author: zach
 */

#include "AppointmentBook.h"
#include "CODEOPT.h"

AppointmentBook::AppointmentBook() {
}

AppointmentBook::~AppointmentBook() {
	for(Appointment* a : this->Appointmentlist){
		if(!a)
			delete a;
	}
}


Appointment* AppointmentBook::createAppointment(ApptType value){
	Appointment* a = nullptr;
	try{
		this->Appointmentlist.push_back(a = this->ABfactory->Create(ToString(value)));
	} catch (int n){
	}
	return a;
}
