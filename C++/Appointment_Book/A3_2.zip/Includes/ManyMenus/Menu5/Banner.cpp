/*
 * Banner.cpp
 *
 *  Created on: 29-Oct-2008
 *      Author: piotr
 */

#include "Banner.h"

Banner::Banner(string s)
: what_(s)
{
}

Banner::~Banner() {
	// TODO Auto-generated destructor stub
}
