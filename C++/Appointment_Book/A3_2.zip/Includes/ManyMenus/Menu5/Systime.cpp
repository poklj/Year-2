/*
 * Systime.cpp
 *
 *  Created on: 29-Oct-2008
 *      Author: piotr
 */

#include "Systime.h"

Systime::Systime() {
	// TODO Auto-generated constructor stub

}

Systime::~Systime() {
	// TODO Auto-generated destructor stub
}
